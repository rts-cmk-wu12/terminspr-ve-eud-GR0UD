"use client";

export default function NoneLayout({ children }) {
  return (
    <>
      <main>{children}</main>
    </>
  );
}
