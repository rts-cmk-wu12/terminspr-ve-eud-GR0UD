export default function Loading() {
  return <div className='global-loading'>Loading...</div>;
}
