export default function CalendarPage() {
  return (
    <main className='calendar-page'>
      <h1 className='calendar-title'>Calendar</h1>
      <p className='calendar-description'>View upcoming events and classes</p>
    </main>
  );
}
