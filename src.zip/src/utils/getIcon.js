import { FiHome, FiSearch, FiCalendar } from "react-icons/fi";

const Icon = {
  home: FiHome,
  search: FiSearch,
  calendar: FiCalendar,
};

export default Icon;
